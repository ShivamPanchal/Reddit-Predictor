
# Reddit Predictor - DS Task

Making a rank/score predictor based on the dataset with Cross validation.



# Installing a package in python


```python
import pip    
def install(package):
   pip.main(['install', package])

# install('package_name')


```

# Loading required packages


```python
%matplotlib inline
import numpy as np
import matplotlib.pyplot as plt
import seaborn; # Seaborn is a library for making attractive and informative statistical graphics in Python
from sklearn.linear_model import LinearRegression
import pylab as pl

seaborn.set()

```

# Getting the current working directory and changing the directory as well.


```python
import os
print os.getcwd()
os.chdir('C://users/Shivam Panchal/Documents')
```

    C:\Users\Shivam Panchal\Documents\scikit-learn-data analysis in python\scikit-learn-videos-master
    


```python
# Importing the Data
import pandas as pd 
data = pd.read_csv('AmericanPolitics.csv')
```

# Exploration of Data


```python
list(data.columns)
```




    ['created_utc',
     'score',
     'domain',
     'id',
     'title',
     'author',
     'ups',
     'downs',
     'num_comments',
     'permalink',
     'selftext',
     'link_flair_text',
     'over_18',
     'thumbnail',
     'subreddit_id',
     'edited',
     'link_flair_css_class',
     'author_flair_css_class',
     'is_self',
     'name',
     'url',
     'distinguished']




```python
data.head(10)
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>created_utc</th>
      <th>score</th>
      <th>domain</th>
      <th>id</th>
      <th>title</th>
      <th>author</th>
      <th>ups</th>
      <th>downs</th>
      <th>num_comments</th>
      <th>permalink</th>
      <th>...</th>
      <th>over_18</th>
      <th>thumbnail</th>
      <th>subreddit_id</th>
      <th>edited</th>
      <th>link_flair_css_class</th>
      <th>author_flair_css_class</th>
      <th>is_self</th>
      <th>name</th>
      <th>url</th>
      <th>distinguished</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.360063e+09</td>
      <td>75</td>
      <td>reason.com</td>
      <td>17xesg</td>
      <td>Someone Just Leaked Obama's Rules for Assassin...</td>
      <td>thebrightsideoflife</td>
      <td>80</td>
      <td>5</td>
      <td>24</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_17xesg</td>
      <td>http://reason.com/blog/2013/02/04/someone-just...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.358034e+09</td>
      <td>63</td>
      <td>petitions.whitehouse.gov</td>
      <td>16gmw0</td>
      <td>Remove United States District Attorney Carmen ...</td>
      <td>djdonnell</td>
      <td>72</td>
      <td>9</td>
      <td>2</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_16gmw0</td>
      <td>https://petitions.whitehouse.gov/petition/remo...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.363187e+09</td>
      <td>54</td>
      <td>slate.com</td>
      <td>1a7ule</td>
      <td>Barack Obama promised transparency: The White ...</td>
      <td>thebrightsideoflife</td>
      <td>61</td>
      <td>7</td>
      <td>1</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_1a7ule</td>
      <td>http://www.slate.com/articles/news_and_politic...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.350433e+09</td>
      <td>44</td>
      <td>rt.com</td>
      <td>11lmw4</td>
      <td>Police arrest US presidential candidate Jill S...</td>
      <td>molib</td>
      <td>48</td>
      <td>4</td>
      <td>13</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_11lmw4</td>
      <td>https://rt.com/usa/news/police-jill-stein-deba...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.313470e+09</td>
      <td>42</td>
      <td>mediaite.com</td>
      <td>jk5ey</td>
      <td>Jon Stewart Scolds Media For Ignoring Rep. Ron...</td>
      <td>thebrightsideoflife</td>
      <td>49</td>
      <td>7</td>
      <td>3</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_jk5ey</td>
      <td>http://www.mediaite.com/tv/jon-stewart-scolds-...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.370519e+09</td>
      <td>40</td>
      <td>theatlantic.com</td>
      <td>1fs9gh</td>
      <td>Thank You, Unknown Patriot, for Exposing the S...</td>
      <td>daylily</td>
      <td>40</td>
      <td>0</td>
      <td>7</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_1fs9gh</td>
      <td>http://www.theatlantic.com/politics/archive/20...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1.352397e+09</td>
      <td>39</td>
      <td>i.imgur.com</td>
      <td>12v6qt</td>
      <td>Forward: Same as it ever was.</td>
      <td>esparza74</td>
      <td>60</td>
      <td>21</td>
      <td>15</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_12v6qt</td>
      <td>http://i.imgur.com/mS0qX.jpg</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1.368535e+09</td>
      <td>39</td>
      <td>youtube.com</td>
      <td>1eb6jf</td>
      <td>Jon Stewart Destroys Obama Over IRS Scandal, '...</td>
      <td>thebrightsideoflife</td>
      <td>45</td>
      <td>6</td>
      <td>60</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_1eb6jf</td>
      <td>https://www.youtube.com/watch?feature=player_e...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1.347925e+09</td>
      <td>41</td>
      <td>motherjones.com</td>
      <td>101sd8</td>
      <td>SECRET VIDEO: Romney Tells Millionaire Donors ...</td>
      <td>yBagno</td>
      <td>48</td>
      <td>7</td>
      <td>2</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_101sd8</td>
      <td>http://www.motherjones.com/politics/2012/09/se...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1.321310e+09</td>
      <td>38</td>
      <td>youtube.com</td>
      <td>mcaml</td>
      <td>Herman Cain struggles to answer question about...</td>
      <td>luvcrunch</td>
      <td>42</td>
      <td>4</td>
      <td>8</td>
      <td>http://www.reddit.com/r/AmericanPolitics/comme...</td>
      <td>...</td>
      <td>False</td>
      <td>NaN</td>
      <td>t5_2qied</td>
      <td>False</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
      <td>t3_mcaml</td>
      <td>http://www.youtube.com/watch?v=WW_nDFKAmCo</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 22 columns</p>
</div>




```python
data.describe()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>created_utc</th>
      <th>score</th>
      <th>ups</th>
      <th>downs</th>
      <th>num_comments</th>
      <th>link_flair_text</th>
      <th>thumbnail</th>
      <th>link_flair_css_class</th>
      <th>author_flair_css_class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>9.970000e+02</td>
      <td>997.000000</td>
      <td>997.000000</td>
      <td>997.000000</td>
      <td>997.000000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.319635e+09</td>
      <td>15.873621</td>
      <td>20.096289</td>
      <td>4.222668</td>
      <td>2.587763</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>std</th>
      <td>4.378123e+07</td>
      <td>6.175323</td>
      <td>7.474640</td>
      <td>3.254988</td>
      <td>4.322303</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.217184e+09</td>
      <td>6.000000</td>
      <td>10.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.294323e+09</td>
      <td>12.000000</td>
      <td>15.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.335820e+09</td>
      <td>14.000000</td>
      <td>18.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1.352232e+09</td>
      <td>18.000000</td>
      <td>23.000000</td>
      <td>6.000000</td>
      <td>3.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.376010e+09</td>
      <td>75.000000</td>
      <td>80.000000</td>
      <td>32.000000</td>
      <td>60.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



# Exploring the relationship between various features and output features.

# Feature Selection

How do I decide which features to include in a linear model? Here's one idea:

Try different models, and only keep predictors in the model if they have small p-values.

Check whether the R-squared value goes up when you add new predictors.

What are the drawbacks to this approach?

Linear models rely upon a lot of assumptions (such as the features being independent), and if those assumptions are violated (which they usually 
are), R-squared and p-values are less reliable.

Using a p-value cutoff of 0.05 means that if you add 100 predictors to a model that are pure noise, 5 of them (on average) will still be counted as significant.

R-squared is susceptible to overfitting, and thus there is no guarantee that a model with a high R-squared value will generalize. Below is an example:


```python
fig = plt.figure()
plot1 = fig.add_subplot(1,1,1)
plot1.scatter(data['score'],data['ups'])
plt.title('Score versus Upvotes')
plt.xlabel('Upvotes')
plt.ylabel('Score')
plt.show()
```


![png](output_15_0.png)



```python
fig = plt.figure()
plot2 = fig.add_subplot(1,1,1)
plot2.scatter(data['score'],data['downs'])
plt.title('Score versus Downvotes')
plt.xlabel('Downvotes')
plt.ylabel('Score')
plt.show()
```


![png](output_16_0.png)



```python
fig = plt.figure()
plot3 = fig.add_subplot(1,1,1)
plot3.scatter(data['score'],data['num_comments'])
plt.title('Score versus Number of Comments')
plt.xlabel('Number of Comments')
plt.ylabel('Score')
plt.show()
```


![png](output_17_0.png)



```python
# visualize the relationship between the features and the response using scatterplots
seaborn.pairplot(data, x_vars=['ups','downs','num_comments'], y_vars='score', size=7, aspect=0.7, kind='reg')
```




    <seaborn.axisgrid.PairGrid at 0xb1006a0>




![png](output_18_1.png)


In the given dataset, we came to the conclusion that, our target feature i.e. SCORE is dependent upon some variables and independent of some varialbles, #'ups' is a strong variable to preddict the score feature.

'downs' and 'num_comments' are not strong features and did not hold any strong relationship for predicting the score feature, but they were assumed to be consisting of a good relation, buts its not true, as can be seen from above graph.


Nw, there are variables such as 
'created_utc', 
'domain', 
'id', 
'title', 
'author', 
'permalink', 
'selftext', 
'link_flair_text', 
'thumbnail', link_flair_css_class',
'author_flair_css_class',
's_self',
'name',
'url', 
'distinguished',
'subreddit_id', 

these have no significant relation in predicting the score feature.

Many of them are even empty columns.

Now, categorical variables like, 'over_18' and 'edited' are also same foe all the posts, so they will also have no significance in predicting the sore feature.


The only variable we are left with is 'ups' , which is a strong feature in predicting the score.





```python
feature_cols = ['ups','downs','num_comments']
X = data[feature_cols]
X.head(10)

```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ups</th>
      <th>downs</th>
      <th>num_comments</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>80</td>
      <td>5</td>
      <td>24</td>
    </tr>
    <tr>
      <th>1</th>
      <td>72</td>
      <td>9</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>61</td>
      <td>7</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>48</td>
      <td>4</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>49</td>
      <td>7</td>
      <td>3</td>
    </tr>
    <tr>
      <th>5</th>
      <td>40</td>
      <td>0</td>
      <td>7</td>
    </tr>
    <tr>
      <th>6</th>
      <td>60</td>
      <td>21</td>
      <td>15</td>
    </tr>
    <tr>
      <th>7</th>
      <td>45</td>
      <td>6</td>
      <td>60</td>
    </tr>
    <tr>
      <th>8</th>
      <td>48</td>
      <td>7</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>42</td>
      <td>4</td>
      <td>8</td>
    </tr>
  </tbody>
</table>
</div>



# Agenda

Using the **train/test split** procedure for model evaluation?
How does **K-fold cross-validation** overcome this limitation?
How can cross-validation be used for selecting **tuning parameters**, choosing between **models**, and selecting **features**?
What are some possible **improvements** to cross-validation?


```python
print(type(X))
print(X.shape)
```

    <class 'pandas.core.frame.DataFrame'>
    (997, 3)
    


```python
y = data['score']
y.head()
```




    0    75
    1    63
    2    54
    3    44
    4    42
    Name: score, dtype: int64




```python
print(type(y))
print(y.shape)
```

    <class 'pandas.core.series.Series'>
    (997L,)
    

# Cross validation for the dataset


```python
from sklearn.cross_validation import cross_val_score
```


```python
from sklearn.datasets import load_iris
from sklearn.cross_validation import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
```


```python
# use train/test split with different random_state values
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=4)

# check classification accuracy of KNN with K=5
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)
print(metrics.accuracy_score(y_test, y_pred))
```

    0.448
    


```python
# simulate splitting a dataset of 25 observations into 5 folds
from sklearn.cross_validation import KFold
kf = KFold(25, n_folds=5, shuffle=False)

# print the contents of each training and testing set
print('{} {:^61} {}'.format('Iteration', 'Training set observations', 'Testing set observations'))
for iteration, data in enumerate(kf, start=1):
    print('{:^9} {} {:^25}'.format(iteration, data[0], data[1]))
```

    Iteration                   Training set observations                   Testing set observations
        1     [ 5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24]        [0 1 2 3 4]       
        2     [ 0  1  2  3  4 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24]        [5 6 7 8 9]       
        3     [ 0  1  2  3  4  5  6  7  8  9 15 16 17 18 19 20 21 22 23 24]     [10 11 12 13 14]     
        4     [ 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 20 21 22 23 24]     [15 16 17 18 19]     
        5     [ 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19]     [20 21 22 23 24]     
    


```python
from sklearn.cross_validation import cross_val_score
```


```python
# 10-fold cross-validation with K=5 for KNN (the n_neighbors parameter)
knn = KNeighborsClassifier(n_neighbors=5)
scores = cross_val_score(knn, X, y, cv=10, scoring='accuracy')
print(scores)
```

    [ 0.44354839  0.5         0.55140187  0.50980392  0.52525253  0.56122449
      0.61956522  0.64835165  0.61363636  0.57142857]
    


```python
# use average accuracy as an estimate of out-of-sample accuracy
print(scores.mean())
```

    0.554421299368
    


```python
# search for an optimal value of K for KNN
k_range = list(range(1, 31))
k_scores = []
for k in k_range:
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn, X, y, cv=10, scoring='accuracy')
    k_scores.append(scores.mean())
print(k_scores)
```

    [0.70330977173661791, 0.63198125671929195, 0.57956438267626298, 0.5748596991655931, 0.55442129936806106, 0.53548129474752582, 0.5106859279584065, 0.4940002576523404, 0.49564786738687727, 0.48311584752416009, 0.46964872171603272, 0.4433289821773142, 0.44158007032462737, 0.43895219819054104, 0.40764037828936966, 0.39908434358102018, 0.38887538332622429, 0.38469683234053287, 0.37191596502969126, 0.36521209727567899, 0.35270790165611843, 0.33132449614845733, 0.32843731608034843, 0.31634163454134018, 0.29490788887778652, 0.29217852517366616, 0.27536677613160321, 0.26695231057424262, 0.25702523683182227, 0.26176655981347785]
    


```python
import matplotlib.pyplot as plt
%matplotlib inline

# plot the value of K for KNN (x-axis) versus the cross-validated accuracy (y-axis)
plt.plot(k_range, k_scores)
plt.xlabel('Value of K for KNN')
plt.ylabel('Cross-Validated Accuracy')
```




    <matplotlib.text.Text at 0xc2333c8>




![png](output_34_1.png)


# Splitting the dataset into training and testin model


```python
from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=1)
```


```python
# default split is 75% for training and 25% for testing
print(X_train.shape)
print(y_train.shape)
print(X_test.shape)
print(y_test.shape)
```

    (747, 3)
    (747L,)
    (250, 3)
    (250L,)
    

# Developing the linear predictive model.


```python
# import model
from sklearn.linear_model import LinearRegression

# instantiate
linreg = LinearRegression()

# fit the model to the training data (learn the coefficients)
linreg.fit(X_train, y_train)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=False)




```python
# print the intercept and coefficients
print(linreg.intercept_)
print(linreg.coef_)
```

    -7.1054273576e-15
    [  1.00000000e+00  -1.00000000e+00   1.36873700e-16]
    


```python
# pair the feature names with the coefficients
list(zip(feature_cols, linreg.coef_))
```




    [('ups', 1.0000000000000004),
     ('downs', -1.0000000000000002),
     ('num_comments', 1.3687369962001413e-16)]




```python
# make predictions on the testing set
y_pred = linreg.predict(X_test)
```


```python
y_pred
```




    array([ 17.,  12.,  13.,   9.,  17.,   9.,  17.,  14.,  14.,  27.,  11.,
            23.,  17.,  17.,  12.,  20.,  23.,  39.,  10.,  13.,  12.,  11.,
            13.,  12.,  10.,  22.,  21.,  12.,  13.,  11.,  10.,  11.,  11.,
            13.,  14.,  17.,  22.,  10.,  12.,  13.,  12.,  13.,  22.,  22.,
            21.,  14.,  13.,  27.,   8.,  13.,  14.,  28.,  12.,  30.,  22.,
            12.,  10.,  11.,  13.,  13.,  17.,  17.,  14.,  13.,  13.,  13.,
            12.,  13.,  13.,  34.,  10.,  11.,  20.,   9.,  15.,  25.,  17.,
            14.,  16.,  12.,  17.,  12.,  10.,  13.,  11.,  15.,  10.,  13.,
            13.,  10.,  13.,  19.,  14.,  11.,  14.,  15.,  11.,  11.,  19.,
            20.,  15.,  35.,  13.,  21.,  10.,  13.,  18.,  12.,  19.,  13.,
            14.,  13.,  11.,  26.,  11.,  20.,  13.,  12.,  24.,  11.,  20.,
            17.,  44.,  17.,  14.,  12.,  10.,  15.,  14.,  12.,  13.,  18.,
            13.,  54.,  11.,  16.,  12.,  11.,  13.,  13.,  25.,  23.,  10.,
            11.,  22.,  11.,  12.,  10.,  12.,  15.,  15.,  13.,  41.,  13.,
            28.,  13.,  16.,  13.,  25.,  17.,  21.,  19.,  21.,  12.,  13.,
            13.,  17.,  12.,  10.,  19.,  19.,  26.,  12.,  13.,  13.,  19.,
            21.,  13.,  11.,  12.,  20.,  26.,  14.,  16.,  15.,  14.,  20.,
            18.,  12.,  15.,  11.,  11.,  17.,  14.,  10.,  15.,  10.,  13.,
            13.,  19.,   9.,   9.,   6.,  29.,  12.,  14.,  31.,  13.,  18.,
            12.,  13.,  16.,  11.,  16.,  11.,  16.,  14.,  20.,  13.,  24.,
            19.,  12.,  17.,  16.,  12.,  10.,  23.,  13.,  11.,  12.,  24.,
            19.,  10.,  13.,  12.,  17.,  17.,  17.,  22.,  37.,  12.,  23.,
            17.,  13.,  14.,  15.,  12.,  13.,  21.,  11.])




```python
# compute the RMSE of our predictions
print(np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
```

    3.77366096265e-15
    


```python

```
